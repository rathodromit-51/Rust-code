fn main() {
    /*TASK -- 01 */
    // let age: i32 = 21;
    // let height: f32 = 186.36;
    // let is_student: bool = false;
    // let grade: char = 'S';
    // let name: &str= "Romit";

    // println!("{age}, {height}, {is_student}, {grade}, {name}") 

    /*TASK -- 02 */
    // let a:i8 = 100;
    // let b:u8 = 200;
    // let c:i32 = -500;
    // let d:u32 = 500;

    // println!("a = {}", a+10);
    // println!("b = {}", b+20);
    // println!("c = {}",c+100);
    // println!("d = {}", d +100)

    /*TASK -- 03 */
    // let age:i32  = 21;
    // let height:f64 = 5.8;

    // let  result:f64 = age as f64 + height;

    // println!("{}", result)

    /*TASK -- 05 */
    // let age: i32 = 21;


    // // age = 22;

    // println!("{age}");

    /*FINAL TASK  */

    let stud_info: (&str, i32, f32, f32, bool, char) = ("Romit", 21, 7.64, 75.6, true, 'A');

    println!("Name = {}", stud_info.0);
    println!("Age = {}", stud_info.1);
    println!("CGPA = {}", stud_info.2);
    println!("Percentage = {}", stud_info.3);
    println!("Pass = {}", stud_info.4);
    println!("Grade = {}", stud_info.5);

}   
